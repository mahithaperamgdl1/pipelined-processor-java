package generic;

import processor.Clock;
import processor.Processor;

//Added - Starts
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;

import processor.memorysystem.MainMemory;
import processor.pipeline.RegisterFile;
//Added - Ends

public class Simulator {
		
	Processor processor;
	static boolean simulationComplete;
	MainMemory mainMemory;

	//FOR-ASSIGNMENT-5 - START
	boolean debug = true;

	static EventQueue eventQueue;
	//FOR-ASSIGNMENT-5 - END

	public void setupSimulation(String assemblyProgramFile, Processor p)
	{
		this.processor = p;
		this.mainMemory = new MainMemory();

		//FOR-ASSIGNMENT-5 - START
		eventQueue = new EventQueue();
		//FOR-ASSIGNMENT-5 - END


		loadProgram(assemblyProgramFile, p.getRegisterFile());
			processor.setMainMemory(mainMemory);
		processor.setRegisterFile(p.getRegisterFile());

		simulationComplete = false;
	}
	
	void loadProgram(String assemblyProgramFile, RegisterFile registerFile)
	{
		if(registerFile == null)
		{
			System.err.println("ERROR: RegisterFile is null. Cannot load program.");
			return;
		}

		/*
		 * TODO
		 * 1. load the program into memory according to the program layout described
		 *    in the ISA specification
		 * 2. set PC to the address of the first instruction in the main
		 * 3. set the following registers:
		 *     x0 = 0
		 *     x1 = 65535
		 *     x2 = 65535
		 */
		
		/*
		1. Loading of the program: Begin with implementing the loadProgram
		function in the file Simulator.java. Store the global data and instructions in the approporiate locations in the mainMemory structure (see Section “Address Space Layout” in assignment 1). Set the PC register to the
		memory address of the first instruction (remember from assignment 2 that
		this is the first integer in the object file). Set x0= 0, x1= 216 − 1, and
		x2= 216 − 1.
		You can check the contents of the memory using processor.getMainMemory()
		.getContentsAsString(<starting-address>, <ending-address>).
		*/
		
		FileInputStream inputStream = null;
		try
		{
			inputStream = new FileInputStream(assemblyProgramFile);
		} catch(FileNotFoundException e) {
			Misc.printErrorAndExit(e.toString());
		}
		
		try {
			byte[] buffer = new byte[4]; // Buffer to hold 4 bytes
			
			int wordRead;
			wordRead = inputStream.read(buffer);
			// System.out.println(wordRead);
			
			int firstCodeAddress = ((buffer[0] & 0xFF) << 24) | 
                    ((buffer[1] & 0xFF) << 16) | 
                    ((buffer[2] & 0xFF) << 8)  | 
                    (buffer[3] & 0xFF);
			// System.out.println(firstCodeAddress);
			
			for(int i=0; i < firstCodeAddress; ++i) {
        		wordRead = inputStream.read(buffer);
        		// Convert the 4 bytes to an integer
                int intValueInside = ((buffer[0] & 0xFF) << 24) | 
                               ((buffer[1] & 0xFF) << 16) | 
                               ((buffer[2] & 0xFF) << 8)  | 
                               (buffer[3] & 0xFF);
                // System.out.println(intValueInside);
                mainMemory.setWord(i, intValueInside);
        	}
			
			int i = firstCodeAddress;
            while ((wordRead = inputStream.read(buffer)) != -1) {
            	// Convert the 4 bytes to an integer
                int instructionIntValue = ((buffer[0] & 0xFF) << 24) | 
                               ((buffer[1] & 0xFF) << 16) | 
                               ((buffer[2] & 0xFF) << 8)  | 
                               (buffer[3] & 0xFF);
            	
                mainMemory.setWord(i, instructionIntValue);
                ++i;
                // System.out.println(instructionIntValue);
            }

			registerFile.setProgramCounter(firstCodeAddress);
			
//			Set x0= 0, x1= 216 − 1, and x2= 216 − 1.
			registerFile.setValue(0, 0);
			
			//FOR DEBUGGING
			// registerFile.setValue(0, 10);
			// registerFile.setValue(3, 13);
			int max = (int) Math.pow(2, 16) - 1;
			registerFile.setValue(1, max );
			registerFile.setValue(2, max );
			
			// //PRINTING MEMORY CONTENT
            // String memoryContent = mainMemory.getContentsAsString(0,100);
			// System.out.println("memoryContent:");
			// System.out.println(memoryContent);

			// //PRINTING REGISTER CONTENT
			// String registerContent = registerFile.getContentsAsString();
			// System.out.println("registerContent:");
			// System.out.println(registerContent);
			
			//ASSIGNMENT-3
			/*
			2. Simulation of the program:
			– The function simulate() in the file src/generic/Simulator.java
			describes the overall loop that captures the simulation. The five
			stages of the processor are called in-order.
			*/
			
			/*
			– As discussed in class, between every two stages, there is a latch. The
			contents of the different latches are obviously different. Therefore, for
			each latch type, a separate class has been created. For example, the
			IF-OF latch is described by the file src/processor/pipeline/IF OF LatchType.java.
			An object of this type is created, and references to the same object
			are given to both the IF stage and the OF stage.
			You have to decide the contents of each latch. IF OF LatchType has
			been done for you. Similarly, implement the remaining latches.
			*/
			/* – Implement each of the stages. The IF stage has been implemented
			for you. Similarly, implement the remaining stages.
			*/
			
			//ASSIGNMENT-4
			/*
			Upgrade the simulator to a pipelined core model.
			• Update your simulate function to a loop that looks something like this:
			w h i l e ( not end o f s i m u l a t i o n )
			{
			performRW
			performMA
			performEX
			performOF
			performIF
			i n c r e m e n t c l o c k by 1
			}
			Each stage must operate on the output generated by the previous stage in
			the previous cycle. If the input latch to the stage has invalid content (e.g.,
			in the very first cycle, MA-RW latch has invalid content), the stage must do
			nothing.
			• Implement data interlocks and control interlocks.
			*/
			
		}
			catch (IOException e) {
				e.printStackTrace();
		}
	}

	public void printCurrentState()
	{
		//PRINTING REGISTER CONTENT
		String registerContent = this.processor.getRegisterFile().getContentsAsString();
		System.out.println("registerContent:");
		System.out.println(registerContent);

		//PRINTING MEMORY CONTENT
		String memoryContent = this.mainMemory.getContentsAsString(0,30);
		System.out.println("memoryContent:");
		System.out.println(memoryContent);
		//DEBUGGING SECTION ENDS
	}
	
	public void simulate()
	{

		int i = 0;
		while(simulationComplete == false)
		{
			// if (debug) this.printCurrentState();

			//RW
			processor.getRWUnit().performRW();
//			Clock.incrementClock();
			// if (debug) this.printCurrentState();


			//MA
			processor.getMAUnit().performMA();
//			Clock.incrementClock();
			// if (debug) this.printCurrentState();


			//EX
			processor.getEXUnit().performEX();
//			Clock.incrementClock();
			// if (debug) this.printCurrentState();
			
			//FOR-ASSIGNMENT-5 - START
			// eventQueue.processEvents( ) ;
			//FOR-ASSIGNMENT-5 - END

			System.out.println("\n PROCESSING EVENTS:");
			System.out.println("Event Queue:" + eventQueue.queue);
			eventQueue.processEvents( ) ;

			//OF
			processor.getOFUnit().performOF();
//			Clock.incrementClock();
			// if (debug) this.printCurrentState();

			//IF
			processor.getIFUnit().performIF();
//			Clock.incrementClock();
			// if (debug) this.printCurrentState();
			
			
			//increment clock by 1 
			System.out.println("Cycle " + ++i);
			if (debug) this.printCurrentState();
			
			Clock.incrementClock();
			System.out.println("Clock:" + Clock.getCurrentTime());
			// if(i==50){
			// 	break;
			// }
			// System.err.println("Simulation Complete: " + simulationComplete);
		}
		
		// TODO
		// set statistics
		Statistics.setNumberOfInstructions(this.processor.EX_IF_Latch.getNumberOfInstructions());
		Statistics.setNumberOfCycles(i);
		//THROUGHPUT CAN ONLY BE CALCULATED WHEN I & C ARE KNOWN
		Statistics.setThroughput();
		Statistics.setCpi();
		Statistics.setNumberOfDataHazards(this.processor.OF_EX_Latch.getNumberOfDataHazards());
		Statistics.setNumberOfBranches(this.processor.EX_IF_Latch.getNumberOfBranches());
		Statistics.setNumberOfCyclesOfOFStalls(this.processor.OF_EX_Latch.getNumberOfCyclesOfOFStalls());

		// System.out.println("Number Of Data Hazards " + this.processor.OF_EX_Latch.getNumberOfDataHazards() );
//		Statistics.setTimeTaken(Clock.getCurrentTime());
	}
	
	public static void setSimulationComplete(boolean value)
	{
		simulationComplete = value;
	}

	//FOR-ASSIGNMENT-5 - START
	public static EventQueue getEventQueue ( )
	{
		return eventQueue ;
	}
}
