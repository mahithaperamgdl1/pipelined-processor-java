package generic;

import java.io.PrintWriter;

public class Statistics {
	
	// TODO add your statistics here
	static int numberOfInstructions;
	static int numberOfCycles;
	static long timeTaken;

	//FOR PIPELINING - START
	static int numberOfBranches;
	static int numberOfDataHazards;
	static int numberOfCyclesOfOFStalls;
	//FOR PIPELINING - END

	static float throughput;
	static float cpi;

	public static void printStatistics(String statFile)
	{
		try
		{
			PrintWriter writer = new PrintWriter(statFile);
			
			writer.println("Number of instructions executed = " + numberOfInstructions);
			
			//FOR REPORT
			// THE NUMBER OF CYCLES TAKEN BY THE PROGRAM
			writer.println("Number of cycles taken = " + numberOfCycles);

			// THE THROUGHPUT IN TERMS OF INSTRUCTIONS PER CYCLE.
			writer.println("The throughput in terms of instructions per cycle (IPC)= " + throughput);
			// writer.println("The throughput in terms of instructions per cycle (IPC)= " + String.format("%.8f", throughput));

			// CPI (INSTRUCTIONS PER CYCLE)
			writer.println("The Cycles per Instruction (CPI)= " + cpi);

			// THE NUMBER OF TIMES THE OF STAGE NEEDED TO STALL BECAUSE OF A DATA HAZARD
			writer.println("Number of times the OF stage needed to stall because of a data hazard = " + numberOfDataHazards);

			// THE NUMBER OF TIMES AN INSTRUCTION ON A WRONG BRANCH PATH ENTERED THE PIPELINE
			writer.println("Number of times an instruction on a wrong branch path entered the pipeline = " + numberOfBranches);

			// NUMBER OF TIMES THE OF STAGE NEEDED TO STALL BECAUSE OF A DATA HAZARD
			writer.println("Number of cycles the OF stage needed to stall because of a data hazard = " + numberOfCyclesOfOFStalls);

			//TOTAL TIME TAKEN BY THE PROGRAM
			// writer.println("Total time taken = " + timeTaken);
			// TODO add code here to print statistics in the output file
			
			writer.close();
		}
		catch(Exception e)
		{
			Misc.printErrorAndExit(e.getMessage());
		}
	}
	
	// TODO write functions to update statistics
	public static void setNumberOfInstructions(int numberOfInstructions) {
		Statistics.numberOfInstructions = numberOfInstructions;
	}

	public static void setNumberOfCycles(int numberOfCycles) {
		Statistics.numberOfCycles = numberOfCycles;
	}

	public static void setTimeTaken(long timeTaken) {
		Statistics.timeTaken = timeTaken;
	}

	//FOR PIPELINING - START
	public static void 	setNumberOfBranches(int numberOfBranches) {
		Statistics.numberOfBranches = numberOfBranches;
	}

	public static void 	setNumberOfDataHazards(int numberOfDataHazards) {
		Statistics.numberOfDataHazards = numberOfDataHazards;
	}

	public static void 	setNumberOfCyclesOfOFStalls(int numberOfCyclesOfOFStalls) {
		Statistics.numberOfCyclesOfOFStalls = numberOfCyclesOfOFStalls;
	}
	//FOR PIPELINING - END

	public static void setThroughput()
	{
		throughput = (float)numberOfInstructions / (float)numberOfCycles;
		// System.out.println(throughput);
	}

	public static void setCpi()
	{
		cpi = (float)numberOfCycles / (float)numberOfInstructions;
		// System.out.println(cpi);
	}
}
