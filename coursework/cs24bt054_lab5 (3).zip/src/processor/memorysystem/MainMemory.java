package processor.memorysystem;

import generic.MemoryReadEvent;
import generic.MemoryResponseEvent;
import generic.MemoryWriteEvent;
import generic.Simulator;
import processor.Clock;
import generic.Element;
import generic.Event;
import processor.pipeline.InstructionFetch;
import processor.pipeline.MemoryAccess;

public class MainMemory implements Element {
	int[] memory;
	
	public MainMemory()
	{
		memory = new int[65536];
	}
	
	public int getWord(int address)
	{
		return memory[address];
	}
	
	public void setWord(int address, int value)
	{
		memory[address] = value;
	}
	
	public String getContentsAsString(int startingAddress, int endingAddress)
	{
		if(startingAddress == endingAddress)
			return "";
		
		StringBuilder sb = new StringBuilder();
		sb.append("\nMain Memory Contents:\n\n");
		for(int i = startingAddress; i <= endingAddress; i++)
		{
			sb.append(i + "\t\t: " + memory[i] + "\n");
		}
		sb.append("\n");
		return sb.toString();
	}

	@Override
	public void handleEvent(Event e) {
		System.out.println("\nMainMemory.handleEvent\n");
		
		if (e.getEventType() == Event.EventType.MemoryRead) {
			MemoryReadEvent event = (MemoryReadEvent) e;

			// Create a new MemoryResponseEvent with the fetched instruction
			Simulator.getEventQueue().addEvent(
				new MemoryResponseEvent(
					Clock.getCurrentTime(),
					this,
					event.getRequestingElement(),
					getWord(event.getAddressToReadFrom()),
					event.getAddressToReadFrom()
				)
			);
			System.out.println("ADDRESS TO READ FROM: " +event.getAddressToReadFrom());
			System.out.println("VALUE READ FROM THE GIVEN ADDRESS: " + getWord(event.getAddressToReadFrom()));

	
			// e.getRequestingElement().IF_EnableLatch.setIFbusy(false);
			if (e.getRequestingElement() instanceof MemoryAccess) {
				((MemoryAccess) e.getRequestingElement()).EX_MA_Latch.setMA_busy(false);
			}
		} else if (e.getEventType() == Event.EventType.MemoryWrite) {
			MemoryWriteEvent event = (MemoryWriteEvent) e;
			setWord(event.getAddressToWriteTo(), event.getValue());

			if (e.getRequestingElement() instanceof MemoryAccess) {
				((MemoryAccess) e.getRequestingElement()).EX_MA_Latch.setMA_busy(false);
				((MemoryAccess) e.getRequestingElement()).MA_RW_Latch.setRW_busy(false);
			}
		}
	}

}
