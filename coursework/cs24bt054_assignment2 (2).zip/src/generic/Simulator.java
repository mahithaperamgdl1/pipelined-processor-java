package generic;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.nio.ByteBuffer;

public class Simulator {

    static FileInputStream inputcodeStream = null;


    static String objectProgramFile;

    public static void setupSimulation(String assemblyProgramFile, String objectProgramFilePath)
    {
        objectProgramFile = objectProgramFilePath;  

        int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
        ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
        ParsedProgram.printState();
    }

    public static void assemble()
    {
        try {
            BufferedOutputStream test =
                    new BufferedOutputStream(new FileOutputStream(objectProgramFile));

            test.write(ByteBuffer.allocate(4)
                                 .putInt(ParsedProgram.firstCodeAddress)
                                 .array());

            for (int d : ParsedProgram.data) {
                test.write(ByteBuffer.allocate(4).putInt(d).array());
            }

            for (Instruction ins : ParsedProgram.code) {
                int b_int = encode(ins, ins.programCounter);
                test.write(ByteBuffer.allocate(4).putInt(b_int).array());
            }

            test.flush();
            test.close();
        }
        catch (Exception e) {
            Misc.printErrorAndExit(e.toString());
        }
    }

    static int encode(Instruction ins, int pc) {
        int opcode = 0;
        int rs1 = 0, rs2 = 0, rd = 0, imm = 0;
        int instruction = 0;

        switch(ins.getOperationType()) {
           
            case add:  opcode = 0b00000; break;
            case sub:  opcode = 0b00010; break;
            case mul:  opcode = 0b00100; break;
            case div:  opcode = 0b00110; break;
            case and:  opcode = 0b01000; break;
            case or:   opcode = 0b01010; break;
            case xor:  opcode = 0b01100; break;
            case slt:  opcode = 0b01110; break;
            case sll:  opcode = 0b10000; break;
            case srl:  opcode = 0b10010; break;
            case sra:  opcode = 0b10100; break;

            case addi: opcode = 0b00001; break;
            case subi: opcode = 0b00011; break;
            case muli: opcode = 0b00101; break;
            case divi: opcode = 0b00111; break;
            case andi: opcode = 0b01001; break;
            case ori:  opcode = 0b01011; break;
            case xori: opcode = 0b01101; break;
            case slti: opcode = 0b01111; break;
            case slli: opcode = 0b10001; break;
            case srli: opcode = 0b10011; break;
            case srai: opcode = 0b10101; break;
            case load: opcode = 0b10110; break;
            case store: opcode = 0b10111; break;

            case jmp:  opcode = 0b11000; break;
            case beq:  opcode = 0b11001; break;
            case bne:  opcode = 0b11010; break;
            case blt:  opcode = 0b11011; break;
            case bgt:  opcode = 0b11100; break;

            case end:  opcode = 0b11101; break;
        }

        if(ins.getOperationType() == Instruction.OperationType.end) {
            return opcode << 27;
        }

        if(ins.getOperationType().toString().matches("add|sub|mul|div|and|or|xor|slt|sll|srl|sra")) {
            rs1 = ins.getSourceOperand1().getValue();
            rs2 = ins.getSourceOperand2().getValue();
            rd  = ins.getDestinationOperand().getValue();
            instruction |= (opcode << 27);
            instruction |= (rs1 << 22);
            instruction |= (rs2 << 17);
            instruction |= (rd << 12);
            return instruction;
        }

        if(ins.getOperationType().toString().matches(
            "addi|subi|muli|divi|andi|ori|xori|slti|slli|srli|srai|load|store")) {

            rs1 = ins.getSourceOperand1().getValue();
            rd  = ins.getDestinationOperand().getValue();

            if(ins.getSourceOperand2().getOperandType() == Operand.OperandType.Immediate)
                imm = ins.getSourceOperand2().getValue();
            else if(ins.getSourceOperand2().getOperandType() == Operand.OperandType.Label)
                imm = ParsedProgram.symtab.get(ins.getSourceOperand2().getLabelValue());

            imm &= 0x1FFFF; 

            instruction |= (opcode << 27);
            instruction |= (rs1 << 22);
            instruction |= (rd << 17);
            instruction |= imm;
            return instruction;
        }

        if(ins.getOperationType().toString().matches("beq|bne|blt|bgt")) {
            rs1 = ins.getSourceOperand1().getValue();
            rs2 = ins.getSourceOperand2().getValue();

            if(ins.getDestinationOperand().getOperandType() == Operand.OperandType.Immediate)
                imm = ins.getDestinationOperand().getValue();
            else if(ins.getDestinationOperand().getOperandType() == Operand.OperandType.Label)
                imm = ParsedProgram.symtab.get(ins.getDestinationOperand().getLabelValue());

            int offset = (imm - pc) & 0x1FFFF; 

            instruction |= (opcode << 27);
            instruction |= (rs1 << 22);
            instruction |= (rs2 << 17);
            instruction |= offset;
            return instruction;
        }

        if(ins.getOperationType() == Instruction.OperationType.jmp) {
            if(ins.getDestinationOperand().getOperandType() == Operand.OperandType.Immediate)
                imm = ins.getDestinationOperand().getValue();
            else if(ins.getDestinationOperand().getOperandType() == Operand.OperandType.Label)
                imm = ParsedProgram.symtab.get(ins.getDestinationOperand().getLabelValue());

            int offset = (imm - pc) & 0x3FFFFF; 

            instruction |= (opcode << 27);
            instruction |= offset;
            return instruction;
        }

        return instruction; 
    }

}

