	.data
a:
	10
	.text
main:
	load %x0, $a, %x3
	add %x0, %x3, %x4
	add %x0, %x0, %x5
loop:
	beq %x0, %x4, endp
	divi %x4, 10, %x4
	muli %x5, 10, %x5
	add %x31, %x5, %x5
	jmp loop
endp:
	beq %x3, %x5, pal
	subi %x0, 1, %x10
	end
pal:
	addi %x0, 1, %x10
	end
