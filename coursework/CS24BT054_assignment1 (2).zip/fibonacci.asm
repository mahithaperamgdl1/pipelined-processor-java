	.data
n:
	10
zero:
	0
	.text
main:
	load %x0, $n, %x3
	addi %x0, 1, %x4
	addi %x0, 0, %x5
	addi %x0, 1, %x6
	addi %x0, 65535, %x7
fib:
	bgt %x4, %x3, endp
	store %x5, $n, %x7
	add %x5, %x6, %x8
	add %x0, %x6, %x5
	add %x0, %x8, %x6
	subi %x7, 1, %x7
	addi %x4, 1, %x4
	jmp fib
endp:
	end
