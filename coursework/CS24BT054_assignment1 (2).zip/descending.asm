	.data
a:
	70
	80
	40
	20
	10
	30
	50
	60
n:
	8
	.text
main:
	load %x0, $n, %x3
	subi %x3, 1, %x3
	add %x0, %x0, %x4
outer:
	bgt %x4, %x3, endp
	add %x0, %x0, %x5
inner:
	sub %x3, %x4, %x6
	bgt %x5, %x6, nexti
	load %x5, $a, %x7
	addi %x5, 1, %x6
	load %x6, $a, %x8
	bgt %x8, %x7, swap
	jmp nextj
swap:
	store %x7, $a, %x6
	store %x8, $a, %x5
nextj:
	addi %x5, 1, %x5
	jmp inner
nexti:
	addi %x4, 1, %x4
	jmp outer
endp:
	end
