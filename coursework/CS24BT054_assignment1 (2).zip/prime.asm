.data
a:
 10
 .text
main:
    load %x0, $a, %x3
    subi %x3, 2, %x6
    blt %x6, %x0, notpr
    subi %x3, 1, %x7
    addi %x0, 2, %x4
loop:
    bgt %x4, %x7, pr
    div %x3, %x4, %x5
    beq %x31, %x0, notpr
    addi %x4, 1, %x4
    jmp loop
notpr:
    subi %x0, 1, %x10
    end
pr:
    addi %x0, 1, %x10
    end
