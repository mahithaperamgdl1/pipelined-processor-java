.data
a:
10
.text
main:
load %x0, $a, %x3
andi %x3, 1, %x4
bne %x4, %x0, odd
subi %x0, 1, %x10
end
odd:
addi %x0, 1, %x10
end
