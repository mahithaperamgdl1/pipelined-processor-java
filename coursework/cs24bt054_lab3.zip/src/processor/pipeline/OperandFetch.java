package processor.pipeline;

import processor.Processor;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}
	
	public void performOF()
	{
		if(IF_OF_Latch.isOF_enable())
		{
			//TODO
			int currentPC = IF_OF_Latch.getCurrentPC();
			int instruction = IF_OF_Latch.getInstruction();
			OF_EX_Latch.setInstruction(instruction);

			
			int immx = instruction & 0x0001ffff;
			OF_EX_Latch.setImmx(immx);

			int offset=0;
			int isJmp = 0;
			int opcode = instruction >>> 27;
			isJmp = (opcode == 24) ? 1 : 0;

			if(isJmp == 1)
			{
				
				int registerNumber = (instruction << 5 & 0xf8000000) >>> 27;
				int isRegister =  (registerNumber == 0) ? 0 : 1;
				

				if(isRegister == 1)
				{
					offset = containingProcessor.getRegisterFile().getValue(registerNumber);
				} else {
					
					offset = instruction & 0x003fffff;
					offset = offset << 10 >> 10;
				}
			} else {
			
				offset = (instruction & 0x0001ffff) << 15 >> 15;
			}
			
			int branchTarget = currentPC + offset;
			

			OF_EX_Latch.setBranchTarget(branchTarget);

			
			int rs1 = 0;
			rs1 = (instruction << 5 & 0xf8000000) >>> 27;

			int rs2 = 0;
			rs2 = (instruction << 10 & 0xf8000000) >>> 27;	

			
			int op1 = containingProcessor.getRegisterFile().getValue(rs1);
			OF_EX_Latch.setOp1(op1);

			int op2 = containingProcessor.getRegisterFile().getValue(rs2);
			OF_EX_Latch.setOp2(op2);

		
			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
		}
	}

}