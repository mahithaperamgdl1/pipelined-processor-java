package processor.pipeline;
import processor.Processor;



public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	int ldResult;

	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
		this.ldResult = 0;
	}
	
	public void performMA()
	{
		//TODO
		int instruction = EX_MA_Latch.getInstruction();
		int AluResult = EX_MA_Latch.getAluResult();
		int op1 = EX_MA_Latch.getOp1();
		int op2 = EX_MA_Latch.getOp2();
		int immx = EX_MA_Latch.getImmx();

		int rd = op2;
		int rs1 = op1;
		

		int opcode = instruction >>> 27;
		switch (opcode) {
		case 22: //load
			System.out.println("Executing: load");
			
			int address = rs1 + immx;
			int value = containingProcessor.getMainMemory().getWord(address);
			ldResult = value;
			break;
		case 23: //store
			System.out.println("Executing: store");
			
			int address2 = rd + immx;
			containingProcessor.getMainMemory().setWord(address2, rs1);
			break;
		default:
			System.out.println("Instruction not supported");
			break;
		}

		
		MA_RW_Latch.setLdResult(ldResult);
		MA_RW_Latch.setAluResult(AluResult);

		
		MA_RW_Latch.setInstruction(instruction);
		EX_MA_Latch.setMA_enable(false);
		MA_RW_Latch.setRW_enable(true);
	}

}