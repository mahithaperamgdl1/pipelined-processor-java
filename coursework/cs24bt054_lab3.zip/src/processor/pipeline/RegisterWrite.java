package processor.pipeline;

import generic.Simulator;
import processor.Processor;
import generic.Statistics;


public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
		if(MA_RW_Latch.isRW_enable())
		{
			//TODO

			Statistics.incrementNumberOfInstructions();

			int instruction = MA_RW_Latch.getInstruction();
			int opcode = instruction >>> 27;
			int result = 0;

			if(opcode == 29) //end INSTRUCTION
			{
				Simulator.setSimulationComplete(true);
				return;
			}
		
			
			
			if(opcode ==22) //load INSTRUCTION
			{
				result = MA_RW_Latch.getLdResult();
				int rd = (instruction << 10 & 0xf8000000) >>> 27;
				containingProcessor.getRegisterFile().setValue(rd, result);
			}
			else 
			{
				result = MA_RW_Latch.getAluResult();
				System.out.println("RegisterWrite: opcode = " + opcode);
				if (opcode >= 0 && opcode <= 21) {
					if(opcode % 2 == 0) //R3 TYPE
					{
						int rd = (instruction << 15 & 0xf8000000) >>> 27;
						containingProcessor.getRegisterFile().setValue(rd, result);
					}
					else //R2i TYPE
					{
						int rd = (instruction << 10 & 0xf8000000) >>> 27;
						containingProcessor.getRegisterFile().setValue(rd, result);
					}
				}
			}
			String registerContent = containingProcessor.getRegisterFile().getContentsAsString();
			System.out.println("registerContent:");
			System.out.println(registerContent);

			MA_RW_Latch.setRW_enable(false);
			IF_EnableLatch.setIF_enable(true);
		}
	}

}