package generic;

import processor.Clock;
import processor.Processor;

//Added - Starts
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;

import processor.memorysystem.MainMemory;
import processor.pipeline.RegisterFile;
//Added - Ends

public class Simulator {
		
	Processor processor;
	static boolean simulationComplete;
	MainMemory mainMemory;	

	public void setupSimulation(String assemblyProgramFile, Processor p)
	{
		this.processor = p;
		this.mainMemory = new MainMemory();
		loadProgram(assemblyProgramFile, p.getRegisterFile());
			processor.setMainMemory(mainMemory);
		processor.setRegisterFile(p.getRegisterFile());

		simulationComplete = false;
	}
	
	void loadProgram(String assemblyProgramFile, RegisterFile registerFile)
	{
		if(registerFile == null)
		{
			System.err.println("ERROR: RegisterFile is null. Cannot load program.");
			return;
		}

		/*
		 * TODO
		 * 1. load the program into memory according to the program layout described
		 *    in the ISA specification
		 * 2. set PC to the address of the first instruction in the main
		 * 3. set the following registers:
		 *     x0 = 0
		 *     x1 = 65535
		 *     x2 = 65535
		 */
		
		
		
		FileInputStream inputStream = null;
		try
		{
			inputStream = new FileInputStream(assemblyProgramFile);
		} catch(FileNotFoundException e) {
			Misc.printErrorAndExit(e.toString());
		}
		
		try {
			byte[] buffer = new byte[4]; 
			
			int wordRead;
			wordRead = inputStream.read(buffer);
			
			int firstCodeAddress = ((buffer[0] & 0xFF) << 24) | 
                    ((buffer[1] & 0xFF) << 16) | 
                    ((buffer[2] & 0xFF) << 8)  | 
                    (buffer[3] & 0xFF);
			
			for(int i=0; i < firstCodeAddress; ++i) {
        		wordRead = inputStream.read(buffer);

				int intValueInside = ((buffer[0] & 0xFF) << 24) | 
                               ((buffer[1] & 0xFF) << 16) | 
                               ((buffer[2] & 0xFF) << 8)  | 
                               (buffer[3] & 0xFF);

							   mainMemory.setWord(i, intValueInside);
        	}
			
			int i = firstCodeAddress;
            while ((wordRead = inputStream.read(buffer)) != -1) {
                int instructionIntValue = ((buffer[0] & 0xFF) << 24) | 
                               ((buffer[1] & 0xFF) << 16) | 
                               ((buffer[2] & 0xFF) << 8)  | 
                               (buffer[3] & 0xFF);
            	
                mainMemory.setWord(i, instructionIntValue);
                ++i;
            }

			registerFile.setProgramCounter(firstCodeAddress);
			
			registerFile.setValue(0, 0);
			
			
			int max = (int) Math.pow(2, 16) - 1;
			registerFile.setValue(1, max );
			registerFile.setValue(2, max );
			
            String memoryContent = mainMemory.getContentsAsString(0,100);
			System.out.println("memoryContent:");
			System.out.println(memoryContent);

			String registerContent = registerFile.getContentsAsString();
			System.out.println("registerContent:");
			System.out.println(registerContent);
			

		}
			catch (IOException e) {
				e.printStackTrace();
		}
	}
	
	public void simulate()
{
    Statistics.setNumberOfInstructions(0);
    Statistics.setNumberOfCycles(0);

    while(simulationComplete == false)
    {
        processor.getIFUnit().performIF();
        processor.getOFUnit().performOF();
        processor.getEXUnit().performEX();
        processor.getMAUnit().performMA();
        processor.getRWUnit().performRW();

        Clock.incrementClock();  
    }

    Statistics.setNumberOfCycles((int) Clock.getCurrentTime());
}

	
	public static void setSimulationComplete(boolean value)
	{
		simulationComplete = value;
	}
}