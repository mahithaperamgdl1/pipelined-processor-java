package generic;

import java.io.PrintWriter;

public class Statistics {
	
	static int numberOfInstructions;
	static int numberOfCycles;

	public static void printStatistics(String statFile)
	{
		try
		{
			PrintWriter writer = new PrintWriter(statFile);
			
			writer.println("Number of instructions executed = " + numberOfInstructions);
			writer.println("Number of cycles taken = " + numberOfCycles);
			
			writer.close();
		}
		catch(Exception e)
		{
			Misc.printErrorAndExit(e.getMessage());
		}
	}
	
	
	public static void setNumberOfInstructions(int value) {
		numberOfInstructions = value;
	}

	public static void setNumberOfCycles(int value) {
		numberOfCycles = value;
	}

	public static void incrementNumberOfInstructions() {
		numberOfInstructions++;
	}

	public static int getNumberOfInstructions() {
		return numberOfInstructions;
	}

	public static int getNumberOfCycles() {
		return numberOfCycles;
	}
}
