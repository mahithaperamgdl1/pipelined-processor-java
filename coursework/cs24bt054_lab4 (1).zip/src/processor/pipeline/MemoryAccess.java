package processor.pipeline;
import processor.Processor;

//TO ACCESS MainMemory & RegisterFile
// import processor.memorysystem.MainMemory;
// import processor.pipeline.RegisterFile;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	int ldResult;

	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
		this.ldResult = 0;
	}
	
	public void performMA()
	{
		if(EX_MA_Latch.isMA_enable())
		{			
			if(EX_MA_Latch.isNop())
			{
				System.out.println("nop in MA");
				MA_RW_Latch.setNop(true);
				MA_RW_Latch.setRd(EX_MA_Latch.getRd());

				EX_MA_Latch.setNop(false);
				return;
			}
			System.out.println("PERFORMING MA");
			MA_RW_Latch.setRd(EX_MA_Latch.getRd());

			//PRINTING THE INSTRUCTION & PC FOR DEBUGGING
			int newInstruction = EX_MA_Latch.getInstruction();

			String binaryString = Integer.toBinaryString(newInstruction);
			while(binaryString.length() < 32)
			{
				binaryString = "0" + binaryString;
			}
			String byte1 = binaryString.substring(0, 8);
			String byte2 = binaryString.substring(8, 16);
			String byte3 = binaryString.substring(16, 24);
			String byte4 = binaryString.substring(24, 32);
			
			System.out.println("Instruction fetched: " + byte1 + " " + byte2 + " " + byte3 + " " + byte4);
			System.out.println("Instruction fetched: " + newInstruction);
			// System.out.println("PC: " + currentPC);
			//DEBUGGING SECTION ENDS

			//TODO
			//GETTING THE INSTRUCTION & ALU RESULT FROM EX_MA_Latch
			int instruction = EX_MA_Latch.getInstruction();
			int AluResult = EX_MA_Latch.getAluResult();
			int op1 = EX_MA_Latch.getOp1();
			int op2 = EX_MA_Latch.getOp2();
			int immx = EX_MA_Latch.getImmx();

			//IMPLEMENTING load & store BOTH R2i-TYPE, rs1 STORED IN op1, immediate STORED IN immx AND rd IS STORED IN 	op2
			int rd = op2;
			int rs1 = op1;
			//NOTE HERE rs1 CONTAINS THE VALUE OF THE REGISTER rs1
			//AND rd CONTAINS THE VALUE OF THE REGISTER rd

			//EXTRACTING OPCODE
			int opcode = instruction >>> 27;
			switch (opcode) {
			case 22: //load
				System.out.println("Executing: load");
				// rd = word at [rs1 + imm]
				int address = rs1 + immx;
				int value = containingProcessor.getMainMemory().getWord(address);
				ldResult = value;
				break;
			case 23: //store
				System.out.println("Executing: store");
				// word at [rd + imm] = rs1
				int address2 = rd + immx;
				containingProcessor.getMainMemory().setWord(address2, rs1);
				break;
			default:
				// System.out.println("Instruction not supported");
				break;
			}

			//PASSING ldResult & AluResult TO MA_RW_Latch
			MA_RW_Latch.setLdResult(ldResult);
			MA_RW_Latch.setAluResult(AluResult);

			//SETTING UP MA_RW_Latch FOR EXECUTION OF RW STAGE
			MA_RW_Latch.setInstruction(instruction);
			// EX_MA_Latch.setMA_enable(false);
			MA_RW_Latch.setRW_enable(true);
		}
		
	}

}
