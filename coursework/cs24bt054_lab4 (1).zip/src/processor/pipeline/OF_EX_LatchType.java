package processor.pipeline;

public class OF_EX_LatchType {
	
	boolean EX_enable;
	int instruction;
	int branchTarget;
	int immx;
	int op1;
	int op2;

	//MODIFICATIONS FOR PIPELINING - STARTS
	boolean nop = false;
	int rd = -1;
	int numberOfDataHazards = 0;
	int numberOfCyclesOfOFStalls = 0;

	public boolean isNop() {
		return nop;
	}

	public void setNop(boolean nop) {
		this.nop = nop;
	}

	public int getRd() {
		return rd;
	}

	public void setRd(int rd) {
		this.rd = rd;
	}

	public int getNumberOfDataHazards() {
		return numberOfDataHazards;
	}

	public void incrementNumberOfDataHazards() {
		this.numberOfDataHazards += 1;
	}

	public int getNumberOfCyclesOfOFStalls() {
		return numberOfCyclesOfOFStalls;
	}

	public void incrementNumberOfCyclesOfOFStalls() {
		this.numberOfCyclesOfOFStalls += 1;
	}
	//MODIFICATIONS FOR PIPELINING - ENDS

	public OF_EX_LatchType()
	{
		EX_enable = false;
	}

	public boolean isEX_enable() {
		return EX_enable;
	}

	public void setEX_enable(boolean eX_enable) {
		EX_enable = eX_enable;
	}

	public int getInstruction() {
		return instruction;
	}

	public void setInstruction(int instruction) {
		this.instruction = instruction;
	}

	public int getImmx() {
		return immx;
	}

	public void setImmx(int immx) {
		this.immx = immx;
	}

	public int getBranchTarget() {
		return branchTarget;
	}

	public void setBranchTarget(int branchTarget) {
		this.branchTarget = branchTarget;
	}

	public int getOp1() {
		return op1;
	}

	public void setOp1(int op1) {
		this.op1 = op1;
	}

	public int getOp2() {
		return op2;	
	}

	public void setOp2(int op2) {
		this.op2 = op2;
	}
}