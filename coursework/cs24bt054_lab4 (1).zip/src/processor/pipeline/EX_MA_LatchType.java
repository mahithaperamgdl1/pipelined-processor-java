package processor.pipeline;

public class EX_MA_LatchType {
	
	boolean MA_enable;
	int instruction;
	int AluResult;
	int op1;
	int op2;
	int immx;
	int WriteBack;

	//MODIFICATIONS FOR PIPELINING - STARTS
	boolean nop = false;
	int rd=-1;

	public boolean isNop() {
		return nop;
	}

	public void setNop(boolean nop) {
		this.nop = nop;
	}

	public int getRd() {
		return rd;
	}

	public void setRd(int rd) {
		this.rd = rd;
	}	
	//MODIFICATIONS FOR PIPELINING - ENDS
	

	public EX_MA_LatchType()
	{
		MA_enable = false;
	}

	public boolean isMA_enable() {
		return MA_enable;
	}

	public void setMA_enable(boolean mA_enable) {
		MA_enable = mA_enable;
	}

	public int getInstruction() {
		return instruction;
	}

	public void setInstruction(int instruction) {
		this.instruction = instruction;
	}

	public int getAluResult() {
		return AluResult;
	}

	public void setAluResult(int aluResult) {
		AluResult = aluResult;
	}

	public int getOp1() {
		return op1;
	}

	public void setOp1(int op1) {
		this.op1 = op1;
	}

	public int getOp2() {
		return op2;
	}

	public void setOp2(int op2) {
		this.op2 = op2;
	}

	public int getImmx() {
		return immx;
	}

	public void setImmx(int immx) {
		this.immx = immx;
	}
	
	public int getWriteBack() {
		return WriteBack;
	}

	public void setWriteBack(int writeBack) {
		WriteBack = writeBack;
	}
	
}
