package processor.pipeline;

import processor.Processor;
import generic.Simulator;

public class Execute {
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;

	//FOR PIPELINING - START
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	//FOR PIPELINING - END

	int isWriteBack;
	int isR2i;
	int isR3;

	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch, EX_IF_LatchType eX_IF_Latch, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;

		//FOR PIPELINING - START
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		//FOR PIPELINING - END

		this.isWriteBack = 0;
		this.isR2i = 0;
		this.isR3 = 0;
	}
	
	public void performEX()
	{
		if(OF_EX_Latch.isEX_enable())
		{
			if(OF_EX_Latch.isNop())
			{
				System.out.println("nop in EX");

				EX_MA_Latch.setNop(true);
				EX_MA_Latch.setRd(OF_EX_Latch.getRd());

				OF_EX_Latch.setNop(false);
				return;
			}
			System.out.println("PERFORMING EX");
			EX_MA_Latch.setRd(OF_EX_Latch.getRd());

			//STATISTICS
			EX_IF_Latch.incrementNumberOfInstructions();

			//TODO
			int instruction = OF_EX_Latch.getInstruction();
			int op1 = OF_EX_Latch.getOp1();
			//op2 contains rs2 (incase of R3 type) & rd (incase of R2i type)
			int op2 = OF_EX_Latch.getOp2();
			int immx = OF_EX_Latch.getImmx();
			//immx CONTAINS immediate value FOR R2i TYPE INSTRUCTIONS

			//EXTRACTING OPCODE
			int opcode = instruction >>> 27;

			//BRACH-UNIT
			//HANDLING BRANCH & JMP INSTRUCTIONS
			int branchTarget = OF_EX_Latch.getBranchTarget();
			int isBranchTaken = 0;

			switch (opcode)
			{
			case 24:
				System.out.println("Executing: jmp");
				//jmp INSTRUCTION (R2i TYPE)
				EX_IF_Latch.setBranchPC(branchTarget);
				isBranchTaken = 1;
				EX_IF_Latch.setIsBranchTaken(isBranchTaken);

				//GO TO InstructionFetch STAGE
				EX_IF_Latch.setIF_enable(true);
				// OF_EX_Latch.setEX_enable(false);
				// EX_MA_Latch.setMA_enable(false);

				//CONVERT INSTRUCTION IN IF & OF STAGE TO nop
				IF_EnableLatch.setNop(true);
				IF_OF_Latch.setNop(true);
				return;
			case 25:
				System.out.println("Executing: beq");
				//beq INSTRUCTION
				if(op1 == op2)
				{
					//SET isBrnachTaken as 1 AND THE branchPC as branchTarget
					EX_IF_Latch.setBranchPC(branchTarget);
					isBranchTaken = 1;
					EX_IF_Latch.setIsBranchTaken(isBranchTaken);

					//GO TO InstructionFetch STAGE
					EX_IF_Latch.setIF_enable(true);
					// OF_EX_Latch.setEX_enable(false);
					// EX_MA_Latch.setMA_enable(false);
					
					//CONVERT INSTRUCTION IN IF & OF STAGE TO nop
					IF_EnableLatch.setNop(true);
					IF_OF_Latch.setNop(true);
				}
				return;
			case 26:
				System.out.println("Executing: bne");
				//bne INSTRUCTION
				if(op1 != op2)
				{
					//SET isBrnachTaken as 1 AND THE branchPC as branchTarget
					EX_IF_Latch.setBranchPC(branchTarget);
					isBranchTaken = 1;
					EX_IF_Latch.setIsBranchTaken(isBranchTaken);

					//GO TO InstructionFetch STAGE
					EX_IF_Latch.setIF_enable(true);
					// OF_EX_Latch.setEX_enable(false);
					// EX_MA_Latch.setMA_enable(false);
					
					//CONVERT INSTRUCTION IN IF & OF STAGE TO nop
					IF_EnableLatch.setNop(true);
					IF_OF_Latch.setNop(true);

				}
				return;
			case 27:
				System.out.println("Executing: blt");
				//blt INSTRUCTION
				if(op1 < op2)
				{
					//SET isBrnachTaken as 1 AND THE branchPC as branchTarget
					EX_IF_Latch.setBranchPC(branchTarget);
					isBranchTaken = 1;
					EX_IF_Latch.setIsBranchTaken(isBranchTaken);

					//GO TO InstructionFetch STAGE
					EX_IF_Latch.setIF_enable(true);
					// OF_EX_Latch.setEX_enable(false);
					// EX_MA_Latch.setMA_enable(false);

					//CONVERT INSTRUCTION IN IF & OF STAGE TO nop
					IF_EnableLatch.setNop(true);
					IF_OF_Latch.setNop(true);

				}
				return;
			case 28:
				System.out.println("Executing: bgt");
				// bgt INSTRUCTION
				if (op1 > op2) {
					// If the condition is true, branch is taken
					// Set the branch target and flag
					EX_IF_Latch.setBranchPC(branchTarget);
					isBranchTaken = 1;
					EX_IF_Latch.setIsBranchTaken(isBranchTaken);
			
					// Enable Instruction Fetch stage and disable the current stages
					EX_IF_Latch.setIF_enable(true);  // Start Instruction Fetch
					// OF_EX_Latch.setEX_enable(false); // Disable Execute stage
					// EX_MA_Latch.setMA_enable(false); // Disable Memory Access stage
			
					//CONVERT INSTRUCTION IN IF & OF STAGE TO nop
					IF_EnableLatch.setNop(true);
					IF_OF_Latch.setNop(true);

				}
				return;
			
			default:
				break;
			}

			switch(opcode)
			{
			case 0:
				System.out.println("Executing: add");
				//add instruction
				EX_MA_Latch.setAluResult(op1 + op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 1:
				System.out.println("Executing: addi");
				//addi instruction
				EX_MA_Latch.setAluResult(op1 + immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 2:
				System.out.println("Executing: sub");
				//sub instruction
				EX_MA_Latch.setAluResult(op1 - op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 3:
				System.out.println("Executing: subi");
				//subi instruction
				EX_MA_Latch.setAluResult(op1 - immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 4:
				System.out.println("Executing: mul");
				//mul instruction
				EX_MA_Latch.setAluResult(op1 * op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 5:
				System.out.println("Executing: muli");
				//muli instruction
				EX_MA_Latch.setAluResult(op1 * immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 6:
				System.out.println("Executing: div");
				//div instruction
				EX_MA_Latch.setAluResult(op1 / op2);
				isWriteBack = 1;
				isR3 = 1;
				int rem = op1 % op2;
				if(OF_EX_Latch.isNop() == false)
				{
					containingProcessor.getRegisterFile().setValue(31, rem);
				}
				break;
			case 7:
				System.out.println("Executing: divi");
				// divi instruction
				EX_MA_Latch.setAluResult(op1 / immx);
				// System.out.println("immx: " + immx);
				// System.out.println("Result: " + EX_MA_Latch.getAluResult());
				isWriteBack = 1;
				isR2i = 1;
				int rem1 = op1 % immx;
				if(OF_EX_Latch.isNop() == false)
				{
					containingProcessor.getRegisterFile().setValue(31, rem1);
				}
				break;
			case 8:
				System.out.println("Executing: and");
				//and instruction
				EX_MA_Latch.setAluResult(op1 & op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 9:
				System.out.println("Executing: andi");
				//andi instruction
				EX_MA_Latch.setAluResult(op1 & immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 10:
				System.out.println("Executing: or");
				//or instruction
				EX_MA_Latch.setAluResult(op1 | op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 11:
				System.out.println("Executing: ori");
				//ori instruction
				EX_MA_Latch.setAluResult(op1 | immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 12:
				System.out.println("Executing: xor");
				//xor instruction
				EX_MA_Latch.setAluResult(op1 ^ op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 13:
				System.out.println("Executing: xori");
				//xori instruction
				EX_MA_Latch.setAluResult(op1 ^ immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 14:
				System.out.println("Executing: slt");
				//slt instruction
				EX_MA_Latch.setAluResult(op1 < op2 ? 1 : 0);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 15:
				System.out.println("Executing: slti");
				//slti instruction
				EX_MA_Latch.setAluResult(op1 < immx ? 1 : 0);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 16:
				System.out.println("Executing: sll");
				//sll instruction
				EX_MA_Latch.setAluResult(op1 << op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 17:
				System.out.println("Executing: slli");
				//slli instruction
				EX_MA_Latch.setAluResult(op1 << immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 18:
				System.out.println("Executing: srl");
				//srl instruction
				EX_MA_Latch.setAluResult(op1 >>> op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 19:
				System.out.println("Executing: srli");
				//srli instruction
				EX_MA_Latch.setAluResult(op1 >>> immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			case 20:
				System.out.println("Executing: sra");
				//sra instruction
				EX_MA_Latch.setAluResult(op1 >> op2);
				isWriteBack = 1;
				isR3 = 1;
				break;
			case 21:
				System.out.println("Executing: srai");
				//srai instruction
				EX_MA_Latch.setAluResult(op1 >> immx);
				isWriteBack = 1;
				isR2i = 1;
				break;
			default:
				break;
			}

			//PAASING op1, op2 AND immx to EX_MA_Latch
			EX_MA_Latch.setOp1(op1);
			EX_MA_Latch.setOp2(op2);
			EX_MA_Latch.setImmx(immx);
			EX_MA_Latch.setWriteBack(isWriteBack);
			// EX_MA_Latch.setR2i(isR2i);
			// EX_MA_Latch.setR3(isR3);

			//FIXING LATCHES
			EX_MA_Latch.setInstruction(instruction);
			// OF_EX_Latch.setEX_enable(false);
			EX_MA_Latch.setMA_enable(true);
		}
	}

}