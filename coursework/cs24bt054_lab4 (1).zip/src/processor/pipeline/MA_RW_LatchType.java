package processor.pipeline;

public class MA_RW_LatchType {
	
	boolean RW_enable;
	int ldResult;
	int instruction;
	int AluResult;

	//MODIFICATIONS FOR PIPELINING - STARTS
	boolean nop = false;
	int rd=-1;

	public boolean isNop() {
		return nop;
	}

	public void setNop(boolean nop) {
		this.nop = nop;
	}

	public int getRd() {
		return rd;
	}

	public void setRd(int rd) {
		this.rd = rd;
	}	
	//MODIFICATIONS FOR PIPELINING - ENDS
	
	
	public MA_RW_LatchType()
	{
		RW_enable = false;
	}

	public boolean isRW_enable() {
		return RW_enable;
	}

	public void setRW_enable(boolean rW_enable) {
		RW_enable = rW_enable;
	}

	public int getLdResult() {
		return ldResult;
	}

	public void setLdResult(int ldResult) {
		this.ldResult = ldResult;
	}

	public int getAluResult() {
		return AluResult;
	}

	public void setAluResult(int aluResult) {
		AluResult = aluResult;
	}

	public int getInstruction() {
		return instruction;
	}

	public void setInstruction(int instruction) {
		this.instruction = instruction;
	}
}
